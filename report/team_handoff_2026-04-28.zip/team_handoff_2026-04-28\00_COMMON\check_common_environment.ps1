$ErrorActionPreference = "Stop"

Write-Host "== Project root =="
Get-Location

Write-Host "`n== Python =="
& "C:\Users\shemanul\anaconda3\envs\gesture-test\python.exe" --version

Write-Host "`n== Required files =="
$required = @(
  "report/mediapipe_재학습_검토.md",
  "report/작업TODO_AND_HISTORY.md",
  "config/mediapipe_real01_xyz.yaml",
  "config/mediapipe_real01_xyz_body.yaml",
  "src/data/preprocess_mediapipe_videos.py",
  "src/data/keypoint_utils.py"
)
foreach ($path in $required) {
  if (Test-Path -LiteralPath $path) {
    Write-Host "[OK] $path"
  } else {
    Write-Host "[MISSING] $path"
  }
}

Write-Host "`n== Disk =="
[System.IO.DriveInfo]::GetDrives() |
  Where-Object { $_.Name -eq "C:\" } |
  ForEach-Object {
    [PSCustomObject]@{
      Name = $_.Name
      TotalGB = [math]::Round($_.TotalSize / 1GB, 2)
      FreeGB = [math]::Round($_.AvailableFreeSpace / 1GB, 2)
    }
  } | Format-Table -AutoSize

Write-Host "`n== Compile check =="
& "C:\Users\shemanul\anaconda3\envs\gesture-test\python.exe" -m py_compile `
  src/data/keypoint_utils.py `
  src/data/preprocess_mediapipe_videos.py `
  scripts/evaluate_local_videos.py

Write-Host "`nDone."
