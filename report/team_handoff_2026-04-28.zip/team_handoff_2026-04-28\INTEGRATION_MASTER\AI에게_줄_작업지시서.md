﻿# AI에게 줄 작업지시서

너는 이 프로젝트의 **REAL 통합 담당자 권오경 팀원을 돕는 AI**다.

각 팀원이 만든 REAL shard 산출물을 받아 하나의 MediaPipe 학습 데이터셋으로 병합한다.

## 먼저 읽을 문서

```text
team_handoff_2026-04-28/00_COMMON/00_반드시_먼저_읽기.md
team_handoff_2026-04-28/00_COMMON/01_역할별_인수인계_지도.md
team_handoff_2026-04-28/00_COMMON/03_REAL번호_병렬처리_규칙.md
```

## 입력으로 받을 shard

```text
handoff_REAL01_REAL03/
handoff_REAL04_REAL06/
handoff_REAL07_REAL09/
handoff_REAL10_REAL12/
handoff_REAL13_REAL16/
```

각 shard 안에는 다음 파일이 있어야 한다.

```text
shard_manifest_REALxx_REALyy.csv
mediapipe_npz_REALxx_REALyy.npz
failed_samples_REALxx_REALyy.csv
preprocess_report_REALxx_REALyy.md
```

## 네가 할 일

```text
1. shard별 필수 파일 존재 확인
2. manifest 컬럼 확인
3. NPZ shape 확인
4. layout/정규화 기준 확인
5. sample_id 중복 확인
6. REAL01~REAL16 누락 범위 확인
7. failed sample 병합
8. master manifest 생성
9. master NPZ 생성
10. merge_report 작성
```

## 고정 기준

```text
MVP labels: 가다, 감사, 괜찮다, 배고프다, 병원, 아프다, 우유, 자다
layout: mediapipe_xyz
feature count: 225
sequence length: 32
normalization: shoulder-center + shoulder-width scale
training/validation 혼합 금지
```

## 최종 산출물

```text
data/processed/mediapipe_master_manifest.csv
data/processed/mediapipe_train_dataset.npz
data/processed/label_map.json
reports/merge_report.md
reports/merge_failed_samples.csv
```

## 완료 전에 확인할 것

```text
모든 shard의 NPZ shape가 (N, 32, 225)인가
manifest row 수와 NPZ sample 수가 일치하는가
MVP 외 단어가 섞이지 않았는가
REAL01~REAL16 누락이 있으면 report에 명시했는가
failed sample을 제외 또는 재처리 기준으로 분리했는가
label_map이 학습/평가/웹에서 동일하게 쓸 수 있는가
```

원본 mp4는 기본적으로 받지 않는다. 특정 실패 샘플 재현이 필요할 때만 해당 팀원에게 개별 mp4를 요청한다.


