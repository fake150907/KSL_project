# AI에게 줄 작업지시서

너는 이 프로젝트의 **REAL shard 담당 작업자 AI**다.

이번 프로젝트는 REAL 번호 기준 병렬 처리로 진행한다.

## 먼저 읽을 문서

작업 전에 반드시 아래 문서를 읽고 기준을 확인한다.

```text
team_handoff_2026-04-28/00_COMMON/00_반드시_먼저_읽기.md
team_handoff_2026-04-28/00_COMMON/01_역할별_인수인계_지도.md
team_handoff_2026-04-28/00_COMMON/02_공통_작업환경_세팅.md
team_handoff_2026-04-28/00_COMMON/03_REAL번호_병렬처리_규칙.md
```

## 네가 맡을 일

사용자가 지정한 REAL 범위에 대해 아래를 끝까지 수행한다.

```text
필요 mp4 확인/확보
MVP 8개 단어 기준 shard manifest 생성
MediaPipe landmark 추출
좌표 정규화 적용
shard NPZ 생성
failed_samples 작성
preprocess_report 작성
```

## 작업 시작 전 반드시 확인

바로 다운로드나 전처리를 시작하지 말고 먼저 기존 산출물을 확인한다.

사용자에게 담당 REAL 범위가 명확하지 않으면 먼저 확인한다.

확인할 위치:

```text
data/raw
data/processed
outputs
team_handoff_outputs
report/작업TODO_AND_HISTORY.md
```

확인 질문 예:

```text
REAL04~REAL06 작업을 시작하기 전에 기존 mp4, manifest, NPZ, report가 있는지 확인하겠습니다.
동일 범위 산출물이 있으면 재사용 가능 여부를 먼저 판단하겠습니다.
```

## 고정 기준

```text
MVP labels: 가다, 감사, 괜찮다, 배고프다, 병원, 아프다, 우유, 자다
layout: mediapipe_xyz
feature: pose33 + left_hand21 + right_hand21
point: [x, y, z]
feature count: 225
sequence length: 32
```

### 정규화 고정 기준

정규화는 아래 방식으로 고정한다. 팀원별로 다른 정규화 방식을 추가하거나 바꾸지 않는다.

정규화에 반영되는 항목은 다음과 같다.

```text
기준점(center)
  사람의 화면 내 위치 차이를 줄이기 위해 양 어깨 중심을 원점처럼 사용한다.

스케일(scale)
  사람마다 카메라 거리와 신체 크기가 다르므로 양 어깨 너비로 좌표 크기를 나눈다.

적용 좌표
  pose33, left_hand21, right_hand21의 모든 [x, y, z] 좌표에 같은 기준점과 scale을 적용한다.

z-depth
  z도 같은 방식으로 상대값으로 정규화하되, 실제 cm/m 같은 절대 거리로 해석하지 않는다.

실패 처리
  어깨 landmark가 없거나 scale이 0에 가까우면 해당 샘플을 failed_samples에 기록한다.
```

```text
normalization: shoulder-center + shoulder-width scale
기준점: 양 어깨 중심
스케일: 양 어깨 너비
left_shoulder: MediaPipe pose[11]
right_shoulder: MediaPipe pose[12]
center = (left_shoulder + right_shoulder) / 2
scale = distance(left_shoulder, right_shoulder)
normalized_point = (point - center) / scale
```

적용 대상:

```text
pose33
left_hand21
right_hand21
```

z는 절대 거리가 아니라 상대 깊이로만 다룬다.

`dx/dy/dz`, 관절 각도, 손가락 굽힘 feature는 1차 shard 작업에서는 추가하지 않는다.

## AIHub 데이터 주의

`01_real_word_video.zip`은 `REAL01`을 뜻하지 않는다.

REAL 번호는 압축 내부 mp4 파일명에서 확인한다.

```text
NIA_SL_WORD1544_REAL01_D.mp4
NIA_SL_WORD1544_REAL04_F.mp4
```

morpheme은 동일 `WORD 번호 + 촬영 각도` 기준으로 REAL 간 공통 참조한다.

## 산출물

담당 범위가 REAL04~REAL06이면 아래처럼 만든다.

```text
team_handoff_outputs/REAL04_REAL06/
  shard_manifest_REAL04_REAL06.csv
  mediapipe_npz_REAL04_REAL06.npz
  failed_samples_REAL04_REAL06.csv
  preprocess_report_REAL04_REAL06.md
```

다른 범위도 같은 이름 규칙을 따른다.

## 권오경 팀원에게 전달할 zip 생성

작업이 끝나면 권오경 팀원에게 전달할 산출물 폴더를 zip으로 묶어 저장한다.

예: 담당 범위가 REAL04~REAL06인 경우

```text
team_handoff_outputs/REAL04_REAL06/
  shard_manifest_REAL04_REAL06.csv
  mediapipe_npz_REAL04_REAL06.npz
  failed_samples_REAL04_REAL06.csv
  preprocess_report_REAL04_REAL06.md

team_handoff_outputs/REAL04_REAL06.zip
```

zip에는 위 4개 산출물이 모두 포함되어야 한다.

권오경 팀원에게 전달할 때는 아래처럼 말한다.

```text
권오경 팀원님, 제 담당 범위 REAL04~REAL06 산출물을 zip으로 묶었습니다.
전달 파일은 team_handoff_outputs/REAL04_REAL06.zip 입니다.
처리 샘플 수와 실패 샘플 수는 preprocess_report_REAL04_REAL06.md에 적었습니다.
```

주의:

```text
원본 mp4, tar, zip.part, checkpoint, AIHub API key는 이 전달 zip에 넣지 않는다.
NPZ는 포함한다. 이 zip은 git에 올리는 용도가 아니라 권오경 팀원에게 전달하는 용도다.
```

## 완료 조건

완료 전에 다음을 확인한다.

```text
담당 REAL 범위만 포함했는가
MVP 8개 단어만 포함했는가
layout이 mediapipe_xyz 225인가
정규화가 shoulder-center + shoulder-width scale인가
manifest와 NPZ sample 순서가 맞는가
실패 샘플이 failed_samples에 기록되었는가
권오경 팀원에게 전달할 REALxx_REALyy.zip을 만들었는가
대용량 mp4/NPZ/checkpoint를 git에 올리지 않았는가
AIHub API key를 파일에 저장하지 않았는가
```
