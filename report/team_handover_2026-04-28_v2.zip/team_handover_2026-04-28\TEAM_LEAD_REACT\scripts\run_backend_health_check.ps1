﻿param(
  [string]$Url = "http://localhost:5000/api/health"
)

$ErrorActionPreference = "Stop"

try {
  Invoke-RestMethod -Uri $Url -Method Get -TimeoutSec 5 | ConvertTo-Json -Depth 10
} catch {
  Write-Host "Backend health check failed: $Url"
  Write-Host "Start backend first:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\TEAM_LEAD_REACT\scripts\run_backend_start.ps1"
  throw
}



