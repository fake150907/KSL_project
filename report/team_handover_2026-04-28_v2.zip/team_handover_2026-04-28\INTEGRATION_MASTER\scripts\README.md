# INTEGRATION_MASTER Python Scripts

The integration master only needs the Python files in this folder.

- `merge_shards.py`: merge received shard manifests and NPZ files into the master training dataset.
- `inspect_npz.py`: print NPZ shape, labels, sequence length, feature count, and sample id summary.

Use the PowerShell wrappers in the parent `INTEGRATION_MASTER` folder first. They call these Python scripts with the expected paths.
