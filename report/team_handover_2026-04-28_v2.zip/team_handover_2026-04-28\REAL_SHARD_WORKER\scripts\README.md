# REAL_SHARD_WORKER Python Scripts

REAL shard workers only need the Python files in this folder.

- `build_shard_manifest_from_videos.py`: create a shard manifest from assigned REAL video files and the morpheme manifest.
- `inspect_npz.py`: print NPZ shape, labels, sequence length, feature count, and sample id summary.

Use the PowerShell wrappers in the parent `REAL_SHARD_WORKER` folder first. They call these Python scripts with the expected paths.
