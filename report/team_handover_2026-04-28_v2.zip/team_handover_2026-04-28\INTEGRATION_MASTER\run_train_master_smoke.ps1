﻿param(
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path,
  [int]$Epochs = 5
)

$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot

$configPath = "config/mediapipe_master_xyz_body.generated.yaml"
@"
paths:
  raw_dir: data/raw
  processed_dir: data/processed
  outputs_dir: outputs
  checkpoints_dir: outputs/checkpoints_mediapipe_master_xyz_body
  reports_dir: outputs/reports_mediapipe_master_xyz_body
  label_candidates: data/label_candidates.csv
  selected_labels: data/selected_labels.json
  selected_labels_small: data/selected_labels_small.json
  subset_manifest: data/processed/mediapipe_master_manifest.csv
  processed_npz: data/processed/mediapipe_train_dataset.npz

data:
  quick_test: true
  max_classes: 8
  max_samples_per_class: 30
  sequence_length: 32
  min_samples_per_class: 1
  validation_ratio: 0.2
  random_seed: 42

preprocess:
  normalize: true
  normalize_mode: mediapipe_xyz_body
  fill_missing: zero
  feature_dims: 3
  landmark_layout: mediapipe_xyz

train:
  baseline_model: random_forest
  epochs: $Epochs
  batch_size: 64
  learning_rate: 0.001
  hidden_size: 64
  num_layers: 1
  dropout: 0.3
  rnn_type: gru
  model_type: cnn_gru
  conv_channels: 64
  num_heads: 4

realtime:
  window_size: 32
  confidence_threshold: 0.35
  cooldown_seconds: 1.0

services:
  tts_backend: local
  stt_backend: local
"@ | Set-Content -LiteralPath $configPath -Encoding UTF8

& $Python -m src.models.train_lstm --config $configPath --epochs $Epochs --model_type cnn_gru --rnn_type gru


