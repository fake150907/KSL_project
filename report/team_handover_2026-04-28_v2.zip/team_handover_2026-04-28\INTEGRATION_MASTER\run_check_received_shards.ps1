﻿param(
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

$shardRoot = Join-Path $ProjectRoot "team_handover_outputs"
$expected = @(
  "REAL01_REAL03",
  "REAL04_REAL06",
  "REAL07_REAL09",
  "REAL10_REAL12",
  "REAL13_REAL16"
)

Write-Host "== Shard root =="
Write-Host $shardRoot

foreach ($rangeTag in $expected) {
  $dir = Join-Path $shardRoot $rangeTag
  Write-Host "`n== $rangeTag =="
  if (-not (Test-Path -LiteralPath $dir)) {
    Write-Host "Missing folder: $dir"
    continue
  }
  $required = @(
    "shard_manifest_$rangeTag.csv",
    "mediapipe_npz_$rangeTag.npz",
    "failed_samples_$rangeTag.csv",
    "preprocess_report_$rangeTag.md"
  )
  foreach ($name in $required) {
    $path = Join-Path $dir $name
    if (Test-Path -LiteralPath $path) {
      $item = Get-Item -LiteralPath $path
      Write-Host ("OK      {0} ({1} bytes)" -f $name, $item.Length)
    } else {
      Write-Host ("MISSING {0}" -f $name)
    }
  }
}


