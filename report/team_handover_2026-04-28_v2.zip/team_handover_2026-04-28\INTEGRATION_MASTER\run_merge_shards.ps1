﻿param(
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path,
  [string]$ShardRoot = "team_handover_outputs",
  [string]$OutputManifest = "data/processed/mediapipe_master_manifest.csv",
  [string]$OutputNpz = "data/processed/mediapipe_train_dataset.npz",
  [string]$LabelMap = "data/processed/label_map.json",
  [string]$MergeReport = "reports/merge_report.md",
  [string]$MergeFailed = "reports/merge_failed_samples.csv"
)

$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot

& $Python "team_handover_2026-04-28\INTEGRATION_MASTER\scripts\merge_shards.py" `
  --shard-root $ShardRoot `
  --output-manifest $OutputManifest `
  --output-npz $OutputNpz `
  --label-map $LabelMap `
  --merge-report $MergeReport `
  --merge-failed $MergeFailed

