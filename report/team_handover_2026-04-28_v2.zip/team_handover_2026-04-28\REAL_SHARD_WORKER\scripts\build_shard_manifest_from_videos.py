﻿"""Build a REAL-range shard manifest from existing mp4 files.

Morpheme timing is matched by WORD id + camera angle. This follows the common
handover rule that a representative morpheme segment can be shared across REAL
ids when the WORD id and angle are the same.

Example:
  python team_handover_2026-04-28/REAL_SHARD_WORKER/scripts/build_shard_manifest_from_videos.py ^
    --real-start 4 ^
    --real-end 6 ^
    --video-dir data/raw/videos ^
    --morpheme-manifest data/training_word_morpheme_manifest_8labels.csv ^
    --output team_handover_outputs/REAL04_REAL06/shard_manifest_REAL04_REAL06.csv
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path


REQUIRED_COLUMNS = {"sample_id", "label", "start", "end", "duration"}
OUTPUT_COLUMNS = [
    "sample_id",
    "label",
    "word_id",
    "real_id",
    "angle",
    "video_path",
    "start",
    "end",
    "duration",
    "npz_index",
    "status",
    "split",
]
SAMPLE_RE = re.compile(r"(?P<word>WORD\d+)_REAL(?P<real>\d+)_(?P<angle>[A-Z])")


def parse_sample_id(sample_id: str) -> tuple[str, str, str]:
    match = SAMPLE_RE.search(sample_id)
    if not match:
        raise ValueError(f"Could not parse sample_id: {sample_id}")
    return match.group("word"), f"REAL{int(match.group('real')):02d}", match.group("angle")


def read_morpheme_manifest(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        missing = REQUIRED_COLUMNS - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f"Missing columns in morpheme manifest: {sorted(missing)}")

        meta_by_word_angle: dict[tuple[str, str], dict[str, str]] = {}
        for row in reader:
            sample_id = row.get("sample_id", "")
            if not sample_id:
                continue
            word_id = row.get("word_id", "")
            angle = row.get("angle", "")
            if not word_id or not angle:
                try:
                    word_id, _real_id, angle = parse_sample_id(sample_id)
                except ValueError:
                    continue
            meta_by_word_angle.setdefault((word_id, angle), row)
        return meta_by_word_angle


def build_rows(
    real_start: int,
    real_end: int,
    video_dir: Path,
    meta_by_word_angle: dict[tuple[str, str], dict[str, str]],
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for real in range(real_start, real_end + 1):
        pattern = f"NIA_SL_WORD*_REAL{real:02d}_*.mp4"
        for video_path in sorted(video_dir.rglob(pattern)):
            sample_id = video_path.stem
            try:
                word_id, real_id, angle = parse_sample_id(sample_id)
            except ValueError:
                continue
            meta = meta_by_word_angle.get((word_id, angle))
            if not meta:
                continue
            rows.append(
                {
                    "sample_id": sample_id,
                    "label": meta["label"],
                    "word_id": word_id,
                    "real_id": real_id,
                    "angle": angle,
                    "video_path": video_path.as_posix(),
                    "start": meta.get("start", ""),
                    "end": meta.get("end", ""),
                    "duration": meta.get("duration", ""),
                    "npz_index": "",
                    "status": "pending",
                    "split": "train",
                }
            )
    return sorted(rows, key=lambda row: (row["label"], row["sample_id"]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--real-start", type=int, required=True)
    parser.add_argument("--real-end", type=int, required=True)
    parser.add_argument("--video-dir", required=True)
    parser.add_argument("--morpheme-manifest", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    video_dir = Path(args.video_dir)
    morpheme_manifest = Path(args.morpheme_manifest)
    output = Path(args.output)

    if not video_dir.exists():
        raise SystemExit(f"Missing video dir: {video_dir}")
    if not morpheme_manifest.exists():
        raise SystemExit(f"Missing morpheme manifest: {morpheme_manifest}")

    meta_by_word_angle = read_morpheme_manifest(morpheme_manifest)
    rows = build_rows(args.real_start, args.real_end, video_dir, meta_by_word_angle)
    if not rows:
        raise SystemExit("No matching rows found. Check REAL range, video_dir, and morpheme manifest.")

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)

    counts: dict[str, int] = {}
    for row in rows:
        counts[row["label"]] = counts.get(row["label"], 0) + 1
    print({"rows": len(rows), "output": str(output), "label_counts": counts})


if __name__ == "__main__":
    main()

