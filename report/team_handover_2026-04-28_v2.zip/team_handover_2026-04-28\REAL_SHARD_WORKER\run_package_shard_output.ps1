﻿param(
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

if ($RealStart -le 0 -or $RealEnd -le 0) {
  Write-Host "Usage:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_package_shard_output.ps1 -RealStart 4 -RealEnd 6"
  exit 2
}

$rangeTag = "REAL{0:D2}_REAL{1:D2}" -f $RealStart, $RealEnd
$outputDir = Join-Path $ProjectRoot "team_handover_outputs\$rangeTag"
$zipPath = Join-Path $ProjectRoot "team_handover_outputs\$rangeTag.zip"

$required = @(
  "shard_manifest_$rangeTag.csv",
  "mediapipe_npz_$rangeTag.npz",
  "failed_samples_$rangeTag.csv",
  "preprocess_report_$rangeTag.md"
)

foreach ($name in $required) {
  $path = Join-Path $outputDir $name
  if (-not (Test-Path -LiteralPath $path)) {
    Write-Host "Missing required output: $path"
    exit 2
  }
}

if (Test-Path -LiteralPath $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}
Compress-Archive -LiteralPath $outputDir -DestinationPath $zipPath
Write-Host "created=$zipPath"


