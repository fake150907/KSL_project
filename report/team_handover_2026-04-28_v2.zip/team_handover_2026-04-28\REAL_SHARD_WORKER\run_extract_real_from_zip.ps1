param(
  [Parameter(Mandatory = $true)]
  [string]$Archive,
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$OutputDir = "data/raw/videos",
  [switch]$Force
)

$ErrorActionPreference = "Stop"

if ($RealStart -le 0 -or $RealEnd -le 0) {
  Write-Host "Usage:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_extract_real_from_zip.ps1 -Archive data\raw\01_real_word_video.zip -RealStart 1 -RealEnd 3 -OutputDir data\raw\videos"
  exit 2
}

if (-not (Test-Path -LiteralPath $Archive)) {
  Write-Host "Missing archive: $Archive"
  exit 2
}

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

Add-Type -AssemblyName System.IO.Compression.FileSystem

$patterns = @()
for ($real = $RealStart; $real -le $RealEnd; $real++) {
  $patterns += ("_REAL{0:D2}_" -f $real)
}

$zipPath = (Resolve-Path -LiteralPath $Archive).Path
$zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
try {
  $selected = $zip.Entries | Where-Object {
    $name = $_.FullName
    $lower = $name.ToLowerInvariant()
    $lower.EndsWith(".mp4") -and ($patterns | Where-Object { $name -like "*$_*" })
  }

  if (-not $selected) {
    Write-Host "No matching REAL mp4 entries found."
    Write-Host "Archive: $Archive"
    Write-Host ("REAL range: REAL{0:D2}~REAL{1:D2}" -f $RealStart, $RealEnd)
    exit 1
  }

  $count = 0
  foreach ($entry in $selected) {
    $fileName = [System.IO.Path]::GetFileName($entry.FullName)
    $target = Join-Path $OutputDir $fileName
    if ((Test-Path -LiteralPath $target) -and -not $Force) {
      Write-Host "[SKIP] $target"
      continue
    }
    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $Force.IsPresent)
    Write-Host "[OK] $target"
    $count += 1
  }

  Write-Host "extracted_count=$count"
} finally {
  $zip.Dispose()
}
