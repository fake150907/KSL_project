﻿"""Merge REAL shard manifests and NPZ files into one training dataset.

Expected shard layout:
  team_handover_outputs/REAL04_REAL06/
    shard_manifest_REAL04_REAL06.csv
    mediapipe_npz_REAL04_REAL06.npz
    failed_samples_REAL04_REAL06.csv
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path

import numpy as np


def read_manifest(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        return [dict(row) for row in reader]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shard-root", default="team_handover_outputs")
    parser.add_argument("--output-manifest", default="data/processed/mediapipe_master_manifest.csv")
    parser.add_argument("--output-npz", default="data/processed/mediapipe_train_dataset.npz")
    parser.add_argument("--label-map", default="data/processed/label_map.json")
    parser.add_argument("--merge-report", default="reports/merge_report.md")
    parser.add_argument("--merge-failed", default="reports/merge_failed_samples.csv")
    args = parser.parse_args()

    shard_root = Path(args.shard_root)
    manifest_paths = sorted(shard_root.glob("*/shard_manifest_*.csv"))
    npz_paths = sorted(shard_root.glob("*/mediapipe_npz_*.npz"))

    if not manifest_paths:
        raise SystemExit(f"No shard manifests found under {shard_root}")
    if not npz_paths:
        raise SystemExit(f"No shard NPZ files found under {shard_root}")

    rows: list[dict[str, str]] = []
    manifest_by_tag: dict[str, dict[str, dict[str, str]]] = {}
    for manifest_path in manifest_paths:
        tag = manifest_path.stem.replace("shard_manifest_", "")
        part_rows = read_manifest(manifest_path)
        manifest_by_tag[tag] = {row["sample_id"]: row for row in part_rows}
        for index, row in enumerate(part_rows):
            row = dict(row)
            row.setdefault("npz_index", str(index))
            row.setdefault("status", "pending")
            row["source_shard"] = tag
            rows.append(row)

    labels = sorted({row["label"] for row in rows if row.get("label")})
    label_to_id = {label: idx for idx, label in enumerate(labels)}

    all_x: list[np.ndarray] = []
    all_y: list[int] = []
    all_splits: list[str] = []
    all_sample_ids: list[str] = []

    for npz_path in npz_paths:
        tag = npz_path.stem.replace("mediapipe_npz_", "")
        manifest = manifest_by_tag.get(tag)
        if manifest is None:
            raise SystemExit(f"Missing matching manifest for {npz_path}")

        data = np.load(npz_path, allow_pickle=True)
        x = data["X"].astype(np.float32)
        sample_ids = [str(item) for item in data["sample_ids"].tolist()]
        splits = [str(item) for item in data["splits"].tolist()] if "splits" in data.files else ["train"] * len(sample_ids)
        if len(sample_ids) != len(x):
            raise SystemExit(f"sample_ids and X length mismatch in {npz_path}")

        for sample_index, sample_id in enumerate(sample_ids):
            row = manifest.get(sample_id)
            if row is None:
                raise SystemExit(f"sample_id missing from shard manifest: {sample_id}")
            all_y.append(label_to_id[row["label"]])
            row["npz_index"] = str(sample_index)
            row["status"] = "ok"

        all_x.append(x)
        all_splits.extend(splits)
        all_sample_ids.extend(sample_ids)

    merged_x = np.concatenate(all_x, axis=0)

    output_npz = Path(args.output_npz)
    output_npz.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output_npz,
        X=merged_x,
        y=np.asarray(all_y, dtype=np.int64),
        splits=np.asarray(all_splits),
        sample_ids=np.asarray(all_sample_ids),
        labels=np.asarray(labels),
    )

    output_manifest = Path(args.output_manifest)
    output_manifest.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with output_manifest.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    label_map = Path(args.label_map)
    label_map.parent.mkdir(parents=True, exist_ok=True)
    label_map.write_text(
        json.dumps({"labels": labels, "label_to_id": label_to_id}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    failed_rows: list[dict[str, str]] = []
    for failed_path in sorted(shard_root.glob("*/failed_samples_*.csv")):
        with failed_path.open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            for row in reader:
                row = dict(row)
                if any(value for value in row.values()):
                    row["source_file"] = failed_path.as_posix()
                    failed_rows.append(row)

    merge_failed = Path(args.merge_failed)
    merge_failed.parent.mkdir(parents=True, exist_ok=True)
    failed_fieldnames = sorted({key for row in failed_rows for key in row.keys()}) or [
        "row_index",
        "sample_id",
        "label",
        "video_path",
        "error",
        "source_file",
    ]
    with merge_failed.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=failed_fieldnames)
        writer.writeheader()
        writer.writerows(failed_rows)

    label_counts = Counter(row.get("label", "") for row in rows if row.get("label"))
    real_counts = Counter(row.get("real_id", "") for row in rows if row.get("real_id"))
    shard_counts = Counter(row.get("source_shard", "") for row in rows if row.get("source_shard"))
    report = Path(args.merge_report)
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        "\n".join(
            [
                "# Merge Report",
                "",
                f"shard_root: {shard_root}",
                f"manifest_rows: {len(rows)}",
                f"npz_samples: {int(merged_x.shape[0])}",
                f"npz_shape: {tuple(int(value) for value in merged_x.shape)}",
                f"output_manifest: {output_manifest}",
                f"output_npz: {output_npz}",
                f"label_map: {label_map}",
                f"merge_failed_samples: {merge_failed}",
                "",
                "## Shard Counts",
                *[f"- {key}: {value}" for key, value in sorted(shard_counts.items())],
                "",
                "## Label Counts",
                *[f"- {key}: {value}" for key, value in sorted(label_counts.items())],
                "",
                "## REAL Counts",
                *[f"- {key}: {value}" for key, value in sorted(real_counts.items())],
                "",
                f"failed_rows: {len(failed_rows)}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(
        {
            "manifest_rows": len(rows),
            "npz_samples": int(merged_x.shape[0]),
            "shape": tuple(int(value) for value in merged_x.shape),
            "output_manifest": str(output_manifest),
            "output_npz": str(output_npz),
            "label_map": str(label_map),
            "merge_report": str(report),
            "merge_failed": str(merge_failed),
        }
    )


if __name__ == "__main__":
    main()

