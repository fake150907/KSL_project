﻿$ErrorActionPreference = "Stop"
Push-Location "web"
try {
  npm.cmd run build
} finally {
  Pop-Location
}


