﻿param(
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

if ($RealStart -le 0 -or $RealEnd -le 0) {
  Write-Host "Usage:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_check_existing_shard.ps1 -RealStart 4 -RealEnd 6"
  exit 2
}

$rangeTag = "REAL{0:D2}_REAL{1:D2}" -f $RealStart, $RealEnd
$outputDir = Join-Path $ProjectRoot "team_handover_outputs\$rangeTag"

Write-Host "== Project root =="
Write-Host $ProjectRoot

Write-Host "`n== Existing output folder =="
if (Test-Path -LiteralPath $outputDir) {
  Get-ChildItem -LiteralPath $outputDir | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize
} else {
  Write-Host "Missing: $outputDir"
}

Write-Host "`n== Existing mp4 candidates under data/raw and raw_video =="
$patterns = @()
for ($real = $RealStart; $real -le $RealEnd; $real++) {
  $patterns += ("*_REAL{0:D2}_*.mp4" -f $real)
}

$videoRoots = @(
  (Join-Path $ProjectRoot "data\raw"),
  (Join-Path $ProjectRoot "raw_video")
) | Where-Object { Test-Path -LiteralPath $_ }

foreach ($root in $videoRoots) {
  Write-Host "`n-- $root"
  foreach ($pattern in $patterns) {
    $count = (Get-ChildItem -LiteralPath $root -Recurse -File -Filter $pattern -ErrorAction SilentlyContinue | Measure-Object).Count
    Write-Host ("{0}: {1}" -f $pattern, $count)
  }
}

Write-Host "`n== Existing project manifests mentioning this REAL range =="
Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File -Filter "*.csv" -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch "\\node_modules\\" } |
  ForEach-Object {
    $path = $_.FullName
    $hit = $false
    for ($real = $RealStart; $real -le $RealEnd; $real++) {
      if (Select-String -LiteralPath $path -Pattern ("REAL{0:D2}" -f $real) -Quiet -ErrorAction SilentlyContinue) {
        $hit = $true
        break
      }
    }
    if ($hit) { $_ }
  } |
  Select-Object FullName, Length, LastWriteTime |
  Format-Table -AutoSize


