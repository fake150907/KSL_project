﻿"""Print the contents and shape of a MediaPipe NPZ file."""

from __future__ import annotations

import argparse
from collections import Counter

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--npz", required=True)
    args = parser.parse_args()

    data = np.load(args.npz, allow_pickle=True)
    print("files:", data.files)
    print("X:", data["X"].shape, data["X"].dtype)
    print("y:", data["y"].shape, data["y"].dtype)
    print("labels:", data["labels"].tolist())

    if "sample_ids" in data.files:
        print("sample_ids_count:", len(data["sample_ids"]))
        if len(data["sample_ids"]):
            print("first_sample_id:", data["sample_ids"][0])

    if "splits" in data.files:
        print("splits:", dict(Counter(str(x) for x in data["splits"].tolist())))

    if data["X"].ndim == 3:
        print("sequence_length:", data["X"].shape[1])
        print("feature_count:", data["X"].shape[2])
        print("first_frame_first_12:", data["X"][0, 0, :12].tolist())

    labels = [str(x) for x in data["labels"].tolist()]
    y = data["y"].tolist()
    if labels and len(y):
        counts = Counter(labels[int(label_id)] for label_id in y)
        print("label_counts:", dict(sorted(counts.items())))


if __name__ == "__main__":
    main()


