﻿param(
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path,
  [string]$Config = "config/mediapipe_real01_xyz.yaml"
)

$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot
$env:SIGN_CONFIG = $Config
$env:MPLCONFIGDIR = Join-Path $ProjectRoot ".matplotlib"
& $Python backend\app.py


