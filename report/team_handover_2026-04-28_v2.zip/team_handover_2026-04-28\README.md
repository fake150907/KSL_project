﻿# Team Handover Package 2026-04-28

이 패키지는 팀원 5명과 팀장이 같은 기준으로 작업하기 위한 **작업 지시/절차 패키지**다.

이 패키지는 원본 mp4, NPZ, checkpoint 같은 대용량 파일을 포함하지 않는다.

## 현재 확정된 작업 방식

이번 작업은 **REAL 번호 기준 병렬 처리**로 진행한다.

```text
권오경 팀원: REAL01~REAL03
최영수 팀원: REAL04~REAL06
김동완 팀원: REAL07~REAL09
김민석 팀원: REAL10~REAL12
서민재 팀원: REAL13~REAL16
윤가연 팀장: React/web demo, 기준 고정, 일정 관리
권오경 팀원: REAL 통합 담당
```

각 팀원은 자기 REAL 범위에 대해 다음 일을 끝까지 수행한다.

```text
필요 mp4 확보
shard manifest 생성
MediaPipe landmark 추출
좌표 정규화 적용
shard NPZ 생성
처리 결과 리포트 작성
```

그 다음 REAL 통합 담당자인 권오경 팀원이 각 팀원의 `NPZ + manifest + report`를 받아 하나의 학습 데이터셋으로 합친다.

## 왜 이렇게 바꾸었나

단계별로 작업을 넘기는 방식은 한 사람이 AIHub에서 대용량 mp4를 받고, 다음 사람이 같은 mp4를 다시 받아야 하는 상황이 생긴다.

현재까지의 테스트 기준으로 training source video는 `01~12_real_word_video.zip` 합산만 약 368GB였고, 목표 범위인 `REAL01~REAL16`으로 넓히면 약 490GB 전후가 필요할 수 있다. 단계별 인계 방식에서는 이 용량이 팀원 사이에서 반복 다운로드되거나 외장 SSD/Google Drive로 계속 전달된다.

REAL 번호 기준으로 나누면 각 팀원이 자기 구간만 확보하고 전처리까지 끝낸다. 통합자는 원본 mp4가 아니라 상대적으로 작은 `NPZ + manifest`만 받으면 된다.

## 먼저 읽을 문서

```text
00_COMMON/00_반드시_먼저_읽기.md
00_COMMON/01_역할별_인수인계_지도.md
00_COMMON/02_공통_작업환경_세팅.md
00_COMMON/03_REAL번호_병렬처리_규칙.md
```

팀원은 그 다음 아래 문서를 읽는다.

```text
REAL_SHARD_WORKER/AI에게_줄_작업지시서.md
REAL_SHARD_WORKER/팀원_작업절차_설명서.md
REAL_SHARD_WORKER/산출물_체크리스트.md
```

REAL 통합 담당자 권오경 팀원은 아래 문서를 읽는다.

```text
INTEGRATION_MASTER/AI에게_줄_작업지시서.md
INTEGRATION_MASTER/팀원_작업절차_설명서.md
```

팀장은 아래 문서를 읽는다.

```text
TEAM_LEAD_REACT/팀장_프로젝트_운영_가이드.md
```

## git에 올리면 안 되는 것

```text
mp4
tar
zip
zip.part
npz
checkpoint
대용량 압축 해제 폴더
AIHub API key
```

git에는 작업 지시서, 실행 스크립트, manifest, status, report 같은 텍스트 산출물만 올린다.

## 포함된 실행 스크립트

이 패키지는 문서만 보는 용도가 아니라, legacy handover처럼 역할별로 바로 실행할 수 있는 PowerShell 스크립트를 함께 포함한다.

공통:

```text
create_output_dirs.ps1
00_COMMON/check_common_environment.ps1
```

REAL shard 작업자:

```text
REAL_SHARD_WORKER/run_check_existing_shard.ps1
REAL_SHARD_WORKER/run_build_shard_manifest_from_videos.ps1
REAL_SHARD_WORKER/run_preprocess_shard.ps1
REAL_SHARD_WORKER/run_inspect_shard_npz.ps1
REAL_SHARD_WORKER/run_package_shard_output.ps1
```

REAL 통합 담당자:

```text
INTEGRATION_MASTER/run_check_received_shards.ps1
INTEGRATION_MASTER/run_merge_shards.ps1
INTEGRATION_MASTER/run_inspect_master_npz.ps1
INTEGRATION_MASTER/run_train_master_smoke.ps1
```

팀장 React/web 담당:

```text
TEAM_LEAD_REACT/scripts/run_web_build_check.ps1
TEAM_LEAD_REACT/scripts/run_web_dev.ps1
TEAM_LEAD_REACT/scripts/run_backend_start.ps1
TEAM_LEAD_REACT/scripts/run_backend_health_check.ps1
```

주의:

```text
이 스크립트들은 실제 프로젝트 루트(C:\github\ai-project-01)의 web, backend, src, config 폴더를 호출한다.
team_handover_2026-04-28.zip 자체에는 원본 mp4, NPZ, checkpoint, React 소스 전체가 들어 있지 않다.
```





