﻿# REAL 번호 병렬 처리 규칙

## 이 방식으로 바꾼 이유

대용량 mp4를 한 사람이 모두 확보한 뒤 다음 작업자에게 넘기는 방식은 파일 전달 문제가 크다.

현재까지의 테스트 기준:

```text
Training source video 01~12 zip 합산: 약 368GB
REAL01~REAL16 목표 범위 예상: 약 490GB 전후
Validation REAL WORD video: 약 118GB
```

한 사람이 약 490GB를 받고 다음 작업자가 같은 범위를 다시 받거나 전달받으면, 팀 전체 다운로드/전달량이 약 980GB 수준으로 커질 수 있고 MediaPipe 전처리도 한 사람에게 몰린다.

그래서 이번에는 REAL 번호 기준으로 나누어 각 팀원이 자기 구간의 mp4 확보부터 NPZ 생성까지 끝낸다.

## 담당 범위

```text
권오경 팀원: REAL01~REAL03
최영수 팀원: REAL04~REAL06
김동완 팀원: REAL07~REAL09
김민석 팀원: REAL10~REAL12
서민재 팀원: REAL13~REAL16
윤가연 팀장: React/web demo, 기준 고정, 일정 관리
권오경 팀원: REAL 통합 담당
```

## 각 팀원이 하는 일

```text
1. 공통 문서 읽기
2. 담당 REAL 범위 확인
3. MVP 8개 단어의 WORD 번호와 angle, morpheme 구간 확인
4. 담당 REAL 범위에 해당하는 mp4 확보
5. shard manifest 생성
6. MediaPipe landmark 추출
7. shoulder-center + shoulder-width scale 정규화 적용
8. shard NPZ 생성
9. failed_samples와 preprocess_report 작성
10. REAL 통합 담당자 권오경 팀원에게 shard 산출물 전달
```

## 고정 기준

```text
MVP labels: 가다, 감사, 괜찮다, 배고프다, 병원, 아프다, 우유, 자다
layout: mediapipe_xyz
feature count: 225
sequence length: 32
normalization: shoulder-center + shoulder-width scale
z-depth: 상대 깊이로만 사용
```

## 산출물 이름 규칙

담당 범위를 파일명에 반드시 넣는다.

예:

```text
handover_REAL01_REAL03/
  shard_manifest_REAL01_REAL03.csv
  mediapipe_npz_REAL01_REAL03.npz
  failed_samples_REAL01_REAL03.csv
  preprocess_report_REAL01_REAL03.md
```

## 하지 말 것

```text
MVP 단어를 임의로 바꾸지 않는다.
REAL 범위를 임의로 바꾸지 않는다.
01_real_word_video.zip을 REAL01로 오해하지 않는다.
OpenPose 201 feature 형식으로 만들지 않는다.
confidence 컬럼을 만들지 않는다.
정규화 방식을 임의로 추가하지 않는다.
training과 validation을 섞지 않는다.
대용량 mp4/npz/checkpoint를 git에 올리지 않는다.
AIHub API key를 문서에 저장하지 않는다.
```

## 권오경 팀원에게 넘기는 기준

각 팀원은 원본 mp4가 아니라 shard 산출물을 넘긴다.

권오경 팀원이 원본 mp4를 요청하는 경우는 실패 샘플 재현이나 이상치 확인처럼 제한된 경우다.
## 압축 해제 원칙

대용량 zip은 전체 압축 해제 후 필요한 파일을 찾는 방식으로 진행하지 않는다.

각 팀원은 압축 내부 mp4 파일명에서 자기 담당 REAL 범위만 선별 추출한다.

```text
REAL01 담당: *_REAL01_*.mp4
REAL04~REAL06 담당: *_REAL04_*.mp4, *_REAL05_*.mp4, *_REAL06_*.mp4
```

`01_real_word_video.zip` 같은 zip 번호는 REAL 번호가 아니다. REAL 번호는 mp4 파일명 안의 `REALxx`를 기준으로 판단한다.
