﻿param(
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$Npz = "",
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot

if (-not $Npz) {
  if ($RealStart -le 0 -or $RealEnd -le 0) {
    Write-Host "Usage:"
    Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_inspect_shard_npz.ps1 -RealStart 4 -RealEnd 6"
    exit 2
  }
  $rangeTag = "REAL{0:D2}_REAL{1:D2}" -f $RealStart, $RealEnd
  $Npz = "team_handover_outputs\$rangeTag\mediapipe_npz_$rangeTag.npz"
}

if (-not (Test-Path -LiteralPath $Npz)) {
  Write-Host "Missing NPZ: $Npz"
  exit 2
}

& $Python "team_handover_2026-04-28\REAL_SHARD_WORKER\scripts\inspect_npz.py" --npz $Npz


