# TEAM_LEAD_REACT Scripts

The React/web lead only needs the PowerShell files in this folder.

- `run_web_build_check.ps1`: check whether the React web project builds.
- `run_web_dev.ps1`: start the React development server.
- `run_backend_start.ps1`: start the Flask backend used by the web demo.
- `run_backend_health_check.ps1`: check whether the backend health endpoint responds.

Use these scripts from the project root unless the procedure document says otherwise.
