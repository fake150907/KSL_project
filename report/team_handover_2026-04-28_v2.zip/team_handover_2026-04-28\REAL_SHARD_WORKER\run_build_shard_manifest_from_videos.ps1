﻿param(
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$VideoDir = "",
  [string]$MorphemeManifest = "",
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

if ($RealStart -le 0 -or $RealEnd -le 0 -or -not $VideoDir -or -not $MorphemeManifest) {
  Write-Host "Usage:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_build_shard_manifest_from_videos.ps1 -RealStart 4 -RealEnd 6 -VideoDir data\raw\videos -MorphemeManifest data\training_word_morpheme_manifest_8labels.csv"
  exit 2
}

Set-Location $ProjectRoot

$rangeTag = "REAL{0:D2}_REAL{1:D2}" -f $RealStart, $RealEnd
$outputDir = Join-Path $ProjectRoot "team_handover_outputs\$rangeTag"
$outputManifest = Join-Path $outputDir "shard_manifest_$rangeTag.csv"
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

& $Python "team_handover_2026-04-28\REAL_SHARD_WORKER\scripts\build_shard_manifest_from_videos.py" `
  --real-start $RealStart `
  --real-end $RealEnd `
  --video-dir $VideoDir `
  --morpheme-manifest $MorphemeManifest `
  --output $outputManifest

