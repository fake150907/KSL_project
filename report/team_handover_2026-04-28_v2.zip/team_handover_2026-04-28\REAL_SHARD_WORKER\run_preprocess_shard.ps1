﻿param(
  [int]$RealStart = 0,
  [int]$RealEnd = 0,
  [string]$Manifest = "",
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

if ($RealStart -le 0 -or $RealEnd -le 0) {
  Write-Host "Usage:"
  Write-Host "  powershell -ExecutionPolicy Bypass -File team_handover_2026-04-28\REAL_SHARD_WORKER\run_preprocess_shard.ps1 -RealStart 4 -RealEnd 6 -Manifest team_handover_outputs\REAL04_REAL06\shard_manifest_REAL04_REAL06.csv"
  exit 2
}

Set-Location $ProjectRoot
$env:MPLCONFIGDIR = Join-Path $ProjectRoot ".matplotlib"
$rangeTag = "REAL{0:D2}_REAL{1:D2}" -f $RealStart, $RealEnd
$outputDir = Join-Path $ProjectRoot "team_handover_outputs\$rangeTag"
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

if (-not $Manifest) {
  $Manifest = Join-Path $outputDir "shard_manifest_$rangeTag.csv"
}
if (-not (Test-Path -LiteralPath $Manifest)) {
  Write-Host "Missing manifest: $Manifest"
  Write-Host "Create it first with run_build_shard_manifest_from_videos.ps1"
  exit 2
}

$npz = Join-Path $outputDir "mediapipe_npz_$rangeTag.npz"
$report = Join-Path $outputDir "preprocess_report_$rangeTag.md"
$failed = Join-Path $outputDir "failed_samples_$rangeTag.csv"

& $Python -m src.data.preprocess_mediapipe_videos `
  --config config/mediapipe_real01_xyz_body.yaml `
  --manifest $Manifest `
  --output $npz `
  --landmark-layout mediapipe_xyz `
  --sequence_length 32 `
  --frame_step 1 `
  --min_hand_frames 1 `
  --model_complexity 1

$autoFailed = [System.IO.Path]::ChangeExtension($npz, ".failed.csv")
if (Test-Path -LiteralPath $autoFailed) {
  Copy-Item -LiteralPath $autoFailed -Destination $failed -Force
} else {
  "row_index,sample_id,label,video_path,error" | Set-Content -LiteralPath $failed -Encoding UTF8
}

$meta = [System.IO.Path]::ChangeExtension($npz, ".meta.json")
$now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
@"
# Preprocess Report

range: $rangeTag
created_at: $now
manifest: $Manifest
npz: $npz
failed_samples: $failed
meta_json: $meta

fixed_standard:
- layout: mediapipe_xyz
- feature_count: 225
- sequence_length: 32
- normalization: shoulder-center + shoulder-width scale

command:
python -m src.data.preprocess_mediapipe_videos --config config/mediapipe_real01_xyz_body.yaml --manifest $Manifest --output $npz --landmark-layout mediapipe_xyz --sequence_length 32
"@ | Set-Content -LiteralPath $report -Encoding UTF8

Write-Host "npz=$npz"
Write-Host "failed=$failed"
Write-Host "report=$report"


