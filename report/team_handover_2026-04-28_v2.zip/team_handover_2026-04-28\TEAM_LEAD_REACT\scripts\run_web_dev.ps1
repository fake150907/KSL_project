﻿param(
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
)

$ErrorActionPreference = "Stop"

Set-Location (Join-Path $ProjectRoot "web")
npm.cmd install
npm.cmd run dev


