﻿param(
  [string]$Python = "python",
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path,
  [string]$Npz = "data/processed/mediapipe_train_dataset.npz"
)

$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot

if (-not (Test-Path -LiteralPath $Npz)) {
  Write-Host "Missing NPZ: $Npz"
  exit 2
}

& $Python "team_handover_2026-04-28\INTEGRATION_MASTER\scripts\inspect_npz.py" --npz $Npz


