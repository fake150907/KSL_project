# FILE Merge Report

file_tags: FILE01_FILE01, FILE02_FILE02, FILE03_FILE03
manifest_rows: 80
npz_samples: 80
npz_shape: (80, 32, 225)
extraction_basis: FILE zip number, not REAL signer number
layout: mediapipe_xyz
feature_count: 225
sequence_length: 32
output_manifest: C:\github\ai-project-01\team_handover_outputs\FILE01_FILE03\shard_manifest_FILE01_FILE03.csv
output_npz: C:\github\ai-project-01\team_handover_outputs\FILE01_FILE03\mediapipe_npz_FILE01_FILE03.npz
label_map: C:\github\ai-project-01\team_handover_outputs\FILE01_FILE03\label_map_FILE01_FILE03.json
merge_failed_samples: C:\github\ai-project-01\team_handover_outputs\FILE01_FILE03\failed_samples_FILE01_FILE03.csv

## FILE Counts
- FILE01_FILE01: 5
- FILE02_FILE02: 70
- FILE03_FILE03: 5

## Label Counts
- 가다: 20
- 감사: 5
- 괜찮다: 5
- 배고프다: 10
- 병원: 5
- 아프다: 5
- 우유: 10
- 자다: 20

## REAL Metadata Counts
- REAL01: 75
- REAL02: 5

failed_rows: 0
